﻿using System;
using System.Collections.Generic;

class Program
{
    static int MaxMaintenanceTasks(List<int[]> intervals)
    {
        intervals.Sort((a, b) => a[1].CompareTo(b[1]));

        int count = 0;
        int lastEnd = -1;

        foreach (var interval in intervals)
        {
            int start = interval[0];
            int end = interval[1];

            if (start >= lastEnd)
            {
                count++;
                lastEnd = end;
            }
        }

        return count;
    }

    static void Main()
    {
        var intervals = new List<int[]>
        {
            new int[] {900, 1030},
            new int[] {1000, 1100},
            new int[] {1030, 1130},
            new int[] {1100, 1200}
        };

        int result = MaxMaintenanceTasks(intervals);
        Console.WriteLine("Maximum tasks: " + result);
    }
}
